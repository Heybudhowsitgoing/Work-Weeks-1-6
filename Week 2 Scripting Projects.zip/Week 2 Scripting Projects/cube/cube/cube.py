def calculate_surface_area(edge_length):
    # Surface area formula for a cube: 6 * edge_length^2
    surface_area = 6 * edge_length ** 2
    return surface_area

def main():
    edge_length = int(input("Enter the length of the cube's edge: "))
    surface_area = calculate_surface_area(edge_length)
    print("Surface area of the cube:", surface_area)

if __name__ == "__main__":
    main()

