def calculate_momentum(mass, velocity):
    momentum = mass * velocity
    return momentum

def main():
    mass = float(input("Enter the mass of the object (in kilograms): "))
    velocity = float(input("Enter the velocity of the object (in meters per second): "))
    
    momentum = calculate_momentum(mass, velocity)
    
    print("The momentum of the object is:", momentum, "kilogram meters per second")

if __name__ == "__main__":
    main()

