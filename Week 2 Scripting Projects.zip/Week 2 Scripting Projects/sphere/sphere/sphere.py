import math

def calculate_diameter(radius):
    diameter = 2 * radius
    return diameter

def calculate_circumference(radius):
    circumference = 2 * math.pi * radius
    return circumference

def calculate_surface_area(radius):
    surface_area = 4 * math.pi * radius ** 2
    return surface_area

def calculate_volume(radius):
    volume = (4/3) * math.pi * radius ** 3
    return volume

def main():
    radius = float(input("Enter the radius of the sphere: "))
    
    diameter = calculate_diameter(radius)
    circumference = calculate_circumference(radius)
    surface_area = calculate_surface_area(radius)
    volume = calculate_volume(radius)
    
    print("Diameter of the sphere:", diameter)
    print("Circumference of the sphere:", circumference)
    print("Surface area of the sphere:", surface_area)
    print("Volume of the sphere:", volume)

if __name__ == "__main__":
    main()

