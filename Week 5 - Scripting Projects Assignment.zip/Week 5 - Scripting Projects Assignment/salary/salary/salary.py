
def main():
    starting_salary = float(input("Enter the starting salary: "))
    percentage_increase = float(input("Enter the percentage increase per year: "))
    years = int(input("Enter the number of years in the schedule: "))

    increase_multiplier = 1 + (percentage_increase / 100)

    print(f"{'Year':<10}{'Salary':<10}")
    print("-" * 20)

    current_salary = starting_salary
    for year in range(1, years + 1):
        print(f"{year:<10}{current_salary:<10.2f}")
        current_salary *= increase_multiplier

if __name__ == "__main__":
    main()

