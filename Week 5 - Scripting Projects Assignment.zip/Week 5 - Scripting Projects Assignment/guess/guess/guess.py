import math

smaller = int(input("Enter the smaller number: "))
larger = int(input("Enter the larger number: "))

# Calculate the maximum number of guesses needed
max_guesses = math.ceil(math.log(larger - smaller + 1, 2))
print(f"I will guess your number in no more than {max_guesses} guesses.")

count = 0
low = smaller
high = larger

while True:
    count += 1
    guess = (low + high) // 2
    print(f"My guess is: {guess}")
    hint = input("Enter 'c' if my guess is correct, 'h' if it's too high, and 'l' if it's too low: ").lower()
    
    if hint == 'c':
        print(f"Congratulations to me! I guessed your number in {count} tries!")
        break
    elif hint == 'h':
        high = guess - 1
    elif hint == 'l':
        low = guess + 1
    else:
        print("Invalid input. Please enter 'c', 'h', or 'l'.")

    if low > high:
        print("It seems like there was a mistake. Let's start over.")
        break

