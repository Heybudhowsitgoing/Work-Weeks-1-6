def main():
    purchase_price = float(input("Enter the purchase price: "))

    down_payment_rate = 0.10
    annual_interest_rate = 0.12
    monthly_payment_rate = 0.05

    down_payment = purchase_price * down_payment_rate
    initial_balance = purchase_price - down_payment
    monthly_payment = purchase_price * monthly_payment_rate

    print(f"{'Month':<10}{'Total Balance':<15}{'Interest':<15}{'Principal':<15}{'Payment':<15}{'Remaining Balance':<20}")
    print("-" * 90)

    month = 0
    balance = initial_balance

    while balance > 0:
        month += 1
        interest = balance * annual_interest_rate / 12
        principal = monthly_payment - interest
        if balance - principal < 0:
            principal = balance
            monthly_payment = interest + principal
        balance -= principal

        print(f"{month:<10}{initial_balance:<15.2f}{interest:<15.2f}{principal:<15.2f}{monthly_payment:<15.2f}{balance:<20.2f}")

        initial_balance = balance

if __name__ == "__main__":
    main()

