def is_equilateral(a, b, c):
    if a == b == c:
        return True
    return False

def main():
    try:
        a = float(input("Enter the length of the first side: "))
        b = float(input("Enter the length of the second side: "))
        c = float(input("Enter the length of the third side: "))
        
        if a <= 0 or b <= 0 or c <= 0:
            print("The lengths of the sides must be positive numbers.")
            return

        if a + b <= c or a + c <= b or b + c <= a:
            print("The given lengths do not form a triangle.")
            return

        if is_equilateral(a, b, c):
            print("The triangle is an equilateral triangle.")
        else:
            print("The triangle is not an equilateral triangle.")
    
    except ValueError:
        print("Please enter valid numbers for the lengths of the sides.")

if __name__ == "__main__":
    main()

