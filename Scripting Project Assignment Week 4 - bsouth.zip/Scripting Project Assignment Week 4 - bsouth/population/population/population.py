def predict_population(initial_population, growth_rate, growth_period, total_hours):
    current_population = initial_population
    periods = total_hours // growth_period

    for _ in range(periods):
        current_population *= growth_rate

    return current_population

def main():
    try:
        initial_population = int(input("Enter the initial number of organisms: "))
        growth_rate = float(input("Enter the growth rate: "))
        growth_period = int(input("Enter the number of hours to achieve the growth rate: "))
        total_hours = int(input("Enter the total number of hours during which the population grows: "))
        
        if initial_population <= 0 or growth_rate <= 0 or growth_period <= 0 or total_hours < 0:
            print("Please enter positive numbers for all inputs, and a non-negative integer for total hours.")
            return

        predicted_population = predict_population(initial_population, growth_rate, growth_period, total_hours)
        
        print(f"The predicted population after {total_hours} hours is: {predicted_population:.0f}")
    
    except ValueError:
        print("Please enter valid numbers for the initial population, growth rate, growth period, and total hours.")

if __name__ == "__main__":
    main()

