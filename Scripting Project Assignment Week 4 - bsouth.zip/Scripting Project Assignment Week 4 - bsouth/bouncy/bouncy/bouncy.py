def calculate_total_distance(initial_height, bounciness_index, number_of_bounces):
    total_distance = 0
    height = initial_height

    for _ in range(number_of_bounces):
        total_distance += height
        height *= bounciness_index
        total_distance += height
    
    total_distance += initial_height
    
    return total_distance

def main():
    try:
        initial_height = float(input("Enter the initial height from which the ball is dropped (in feet): "))
        bounciness_index = float(input("Enter the bounciness index of the ball: "))
        number_of_bounces = int(input("Enter the number of times the ball is allowed to bounce: "))
        
        if initial_height <= 0 or bounciness_index <= 0 or bounciness_index >= 1 or number_of_bounces < 0:
            print("Please enter valid positive numbers for height, a bounciness index between 0 and 1, and a non-negative integer for the number of bounces.")
            return

        total_distance = calculate_total_distance(initial_height, bounciness_index, number_of_bounces)
        
        print(f"The total distance traveled by the ball is: {total_distance:.2f} feet")
    
    except ValueError:
        print("Please enter valid numbers for the height, bounciness index, and number of bounces.")

if __name__ == "__main__":
    main()

