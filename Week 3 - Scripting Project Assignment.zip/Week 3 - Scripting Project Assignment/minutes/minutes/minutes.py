# minutes.py

def calculate_minutes(years):
   
    minutes_per_year = 365 * 24 * 60
    total_minutes = years * minutes_per_year
    return total_minutes

def main():
    years = int(input("Enter the number of years: "))
    minutes = calculate_minutes(years)
    print(f"The number of minutes in {years} years is: {minutes}")

if __name__ == "__main__":
    main()

