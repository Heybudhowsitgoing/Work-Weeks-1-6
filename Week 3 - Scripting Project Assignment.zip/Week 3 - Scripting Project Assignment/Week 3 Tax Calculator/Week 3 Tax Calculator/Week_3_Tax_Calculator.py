# taxform.py

def calculate_tax(income, tax_rate):
    tax = income * tax_rate
    return tax

def main():
    income = float(input("Enter your income: "))
    tax_rate = float(input("Enter the tax rate: "))
    
    tax = calculate_tax(income, tax_rate)
    rounded_tax = round(tax, 2)
    print("The calculated tax is: ", rounded_tax)

if __name__ == "__main__":
    main()

