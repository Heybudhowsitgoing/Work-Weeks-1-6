def caesar_cipher_encrypt(plaintext, distance):
    encrypted_text = ""
    for char in plaintext:
        if 32 <= ord(char) <= 126:  
            shifted = ord(char) + distance
            while shifted > 126:
                shifted = 31 + (shifted - 126)
            encrypted_text += chr(shifted)
        else:
            encrypted_text += char  
    return encrypted_text

def main():
    plaintext = input("Enter the plaintext: ")
    distance = int(input("Enter the distance value: "))
    encrypted_text = caesar_cipher_encrypt(plaintext, distance)
    print("Encrypted text:", encrypted_text)

if __name__ == "__main__":
    main()

