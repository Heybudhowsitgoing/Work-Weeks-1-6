def caesar_cipher_decrypt(encrypted_text, distance):
    decrypted_text = ""
    for char in encrypted_text:
        if 32 <= ord(char) <= 126:  
            shifted = ord(char) - distance
            while shifted < 32:
                shifted = 127 - (32 - shifted)
            decrypted_text += chr(shifted)
        else:
            decrypted_text += char  
    return decrypted_text

def main():
    encrypted_text = input("Enter the encrypted text: ")
    distance = int(input("Enter the distance value: "))
    decrypted_text = caesar_cipher_decrypt(encrypted_text, distance)
    print("Decrypted text:", decrypted_text)

if __name__ == "__main__":
    main()

