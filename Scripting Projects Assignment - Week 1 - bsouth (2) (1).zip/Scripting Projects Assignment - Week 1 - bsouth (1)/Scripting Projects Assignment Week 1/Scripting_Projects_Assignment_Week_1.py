
radius = float(input("Enter the radius of the circle: "))

area = 3.14 * radius ** 2

print("The area of the circle is", area, "square units.")
