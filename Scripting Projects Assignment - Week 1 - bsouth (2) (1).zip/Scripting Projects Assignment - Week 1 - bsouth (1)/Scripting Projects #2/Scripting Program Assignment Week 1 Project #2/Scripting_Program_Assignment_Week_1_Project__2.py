name = "Braden"
address = "1801 E 4th St"
telephone_number = "9183409037"

print("Name:", name)
print("Address:", address)
print("Telephone Number:", telephone_number)
